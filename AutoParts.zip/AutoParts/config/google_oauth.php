<?php

return [
    'client_id'     => '311860850282-pkn2spadfmveqio6bboc7ursck5jkauj.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri'  => 'http://localhost/auth/google/callback',
    'scopes'        => [
        'openid',
        'email',
        'profile',
    ],
];
